import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DioClient {
  static final DioClient _instance = DioClient._internal();
  factory DioClient() => _instance;
  DioClient._internal();

  late Dio dio;

  void init() {
    print('📌 [DioClient] شروع مقداردهی...');

    dio = Dio(BaseOptions(
      baseUrl: 'https://docker-raw80k.chbkn.run',
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      headers: {
        'Content-Type': 'application/json',
      },
    ));

    // لاگ برای تمام درخواست‌ها
    dio.interceptors.add(LogInterceptor(
      request: true,
      requestHeader: true,
      requestBody: true,
      responseHeader: true,
      responseBody: true,
      error: true,
      logPrint: (log) {
        print('🌐 [DIO] $log');
      },
    ));

    // اینترسپتور برای توکن
    dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        print('📤 [REQUEST] ${options.method} ${options.path}');
        print('📤 [REQUEST Headers] ${options.headers}');
        print('📤 [REQUEST Body] ${options.data}');

        final prefs = await SharedPreferences.getInstance();
        final token = prefs.getString('auth_token');

        if (token != null && token.isNotEmpty) {
          options.headers['Authorization'] = 'Bearer $token';
          print('✅ [TOKEN] توکن به هدر اضافه شد: $token');
        } else {
          print('⚠️ [TOKEN] توکنی یافت نشد');
        }

        return handler.next(options);
      },
      onResponse: (response, handler) {
        print('📥 [RESPONSE] ${response.statusCode} ${response.requestOptions.path}');
        print('📥 [RESPONSE Body] ${response.data}');
        return handler.next(response);
      },
      onError: (error, handler) {
        print('❌ [ERROR] ${error.message}');
        print('❌ [ERROR Response] ${error.response?.data}');
        print('❌ [ERROR StatusCode] ${error.response?.statusCode}');

        if (error.response?.statusCode == 401) {
          print('🔐 [AUTH] توکن نامعتبر است');
        }
        return handler.next(error);
      },
    ));

    print('✅ [DioClient] مقداردهی با موفقیت انجام شد');
  }
}