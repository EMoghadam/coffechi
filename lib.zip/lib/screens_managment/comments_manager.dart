import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../theme/app_text_theme.dart';

class CommentsManager extends StatelessWidget {
  const CommentsManager({super.key});

  @override
  Widget build(BuildContext context) {
    // داده‌های نمونه (در پروژه واقعی از API دریافت می‌شود)
    final List<Map<String, dynamic>> reviews = [
      {
        'user': 'علی محمدی',
        'rating': 5,
        'date': '1403/08/10 - 14:30',
        'text': 'کافه عالی بود! قهوه اسپرسو فوق‌العاده بود.',
        'products': ['اسپرسو', 'کیک شکلاتی'],
      },
      {
        'user': 'سارا احمدی',
        'rating': 3,
        'date': '1403/08/09 - 10:15',
        'text': 'محیط آرامی داشت، اما سرویس‌دهی کمی کند بود.',
        'products': ['لاته', 'ساندویچ مرغ'],
      },
    ];


    return Scaffold(



      appBar: AppBar(
        centerTitle: true,
        excludeHeaderSemantics: true,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: AppColors.tertiary,
        title: Text(
          'نظرات کاربران',
          style: AppTextTheme.textTheme.bodyLarge!.copyWith(
            color: AppColors.secondary,
          ),
        ),
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: reviews.length,
          itemBuilder: (context, index) {
            final review = reviews[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // هدر: نام کاربر، امتیاز و تاریخ
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            review['user'],
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Row(crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            ...List.generate(
                              review['rating'],
                                  (i) => const Icon(Icons.star, color: Colors.amber, size: 20),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(right: 5),
                              child: Text(
                                review['rating'].toString(),
                                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                              ),
                            ),
                          ]

                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      review['date'],
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 12),
                    // متن نظر
                    Text(
                      review['text'],
                      style: const TextStyle(fontSize: 14, height: 1.4),
                    ),
                    const SizedBox(height: 12),
                    // لیست محصولات
                    const Text(
                      'محصولات سفارش داده شده:',
                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: (review['products'] as List).map((product) {
                       return Chip(
                          label: Text(product),
                          backgroundColor: AppColors.tertiary,
                          labelStyle: TextStyle(color: AppColors.secondary),
                          // تنظیمات حاشیه و شعاع گوشه
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12), // افزایش شعاع گوشه‌ها
                            side: const BorderSide(color: Colors.transparent, width: 0), // حاشیه مشکی
                          ),
                        );

                      }).toList(),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
