import 'package:coffechi2/theme/app_colors.dart';
import 'package:coffechi2/theme/app_text_theme.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class EditProfilePage extends StatefulWidget {
  final String initialName;
  final String initialAddress;
  final String initialPhone;
  final String initialHours;
  final String initialCategories;
  final String initialImageUrl;

  const EditProfilePage({
    super.key,
    required this.initialName,
    required this.initialAddress,
    required this.initialPhone,
    required this.initialHours,
    required this.initialCategories,
    required this.initialImageUrl,
  });

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();
  final _hoursController = TextEditingController();
  final _categoriesController = TextEditingController();

  File? _selectedImage;
  List<String> _selectedCategories = [];
  final List<String> _availableCategories = [
    'کافه',
    'رستوران',
    'فست فود',
  ];

  @override
  void initState() {
    super.initState();
    // مقداردهی اولیه فیلدها با اطلاعات پروفایل
    _nameController.text = widget.initialName;
    _addressController.text = widget.initialAddress;
    _phoneController.text = widget.initialPhone;
    _hoursController.text = widget.initialHours;
    _categoriesController.text = widget.initialCategories;

    // پارس کردن دسته‌بندی‌های انتخاب شده
    _selectedCategories = widget.initialCategories
        .split('،')
        .where((c) => c.trim().isNotEmpty)
        .toList();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _addressController.dispose();
    _phoneController.dispose();
    _hoursController.dispose();
    _categoriesController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  void _saveProfile() {
    if (_formKey.currentState!.validate()) {
      // اینجا می‌توانید اطلاعات را ذخیره کنید (API یا SharedPreferences)
      ScaffoldMessenger.of(context).showSnackBar(
         SnackBar(
          content: Directionality(
              textDirection: TextDirection.rtl,child: Text('پروفایل با موفقیت به‌روزرسانی شد!',style: TextStyle(color:  AppColors.secondary),)),
          backgroundColor: AppColors.tertiary,
        ),
      );

      // بازگشت به صفحه پروفایل با اطلاعات جدید
      Navigator.pop(context, {
        'name': _nameController.text,
        'address': _addressController.text,
        'phone': _phoneController.text,
        'hours': _hoursController.text,
        'categories': _selectedCategories.join('، '),
        'image': _selectedImage?.path ?? widget.initialImageUrl,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'ویرایش پروفایل',
          style: AppTextTheme.textTheme.bodyLarge!.copyWith(
            color: AppColors.secondary,
          ),
        ),
        centerTitle: true,
        backgroundColor: AppColors.tertiary,
        elevation: 0,
        actions: [
          TextButton(
            onPressed: _saveProfile,
            child: const Text(
              'ذخیره',
              style: TextStyle(
                color: AppColors.secondary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // بخش عکس پروفایل
                GestureDetector(
                  onTap: _pickImage,
                  child: Container(
                    height: 120,
                    width: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.primary, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.3),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: _selectedImage != null
                          ? Image.file(_selectedImage!, fit: BoxFit.cover)
                          : Image.network(
                              widget.initialImageUrl,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) =>
                                  const Icon(
                                    Icons.restaurant,
                                    size: 50,
                                    color: Colors.grey,
                                  ),
                            ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                const Text(
                  'عکس پروفایل',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),

                const SizedBox(height: 20),

                // نام کافه
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: 'نام کافه/رستوران',
                    prefixIcon: const Icon(Icons.restaurant_menu),
                    filled: true,
                    fillColor: Colors.grey[50],

                    // ۱. بوردر غیرفعال (پیش‌فرض)
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color:AppColors.black6,
                        width: 1.5,
                      ),
                    ),

                    // ۲. بوردر فعال (نارنجی)
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:  BorderSide(
                        color: AppColors.primary,
                        width: 2.0,
                      ),
                    ),

                    labelStyle: const TextStyle(
                      color:AppColors.black6,
                    ), // رنگ پیش‌فرض متن
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'نام کافه الزامی است';
                    }
                    return null;
                  },
                ),

                const SizedBox(height: 20),

                // آدرس
                TextFormField(
                  controller: _addressController,
                  maxLines: 2,
                  decoration: InputDecoration(
                    labelText: 'آدرس کامل',
                    prefixIcon: const Icon(Icons.location_on),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color:AppColors.black6,
                        width: 1.5,
                      ),
                    ),

                    // ۲. بوردر فعال (نارنجی)
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:  BorderSide(
                        color: AppColors.primary,
                        width: 2.0,
                      ),
                    ),

                    labelStyle: const TextStyle(
                      color:AppColors.black6,
                    ), // رنگ پیش‌فرض متن
                    filled: true,
                    fillColor: Colors.grey[50],
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'آدرس الزامی است';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),

                // تلفن
                TextFormField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    labelText: 'شماره تلفن',
                    prefixIcon: const Icon(Icons.phone),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color:AppColors.black6,
                        width: 1.5,
                      ),
                    ),

                    // ۲. بوردر فعال (نارنجی)
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:  BorderSide(
                        color: AppColors.primary,
                        width: 2.0,
                      ),
                    ),

                    labelStyle: const TextStyle(
                      color:AppColors.black6,
                    ), // رنگ پیش‌فرض متن
                    filled: true,
                    fillColor: Colors.grey[50],
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'شماره تلفن الزامی است';
                    }
                    if (!RegExp(
                      r'^\d{11}$',
                    ).hasMatch(value.replaceAll(RegExp(r'[^\d]'), ''))) {
                      return 'شماره تلفن معتبر نیست';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),

                // ساعات کاری
                TextFormField(
                  controller: _hoursController,
                  decoration: InputDecoration(
                    labelText: 'ساعات کاری (مثال: شنبه تا پنجشنبه ۸-۲۲)',
                    prefixIcon: const Icon(Icons.access_time),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(
                        color:AppColors.black6,
                        width: 1.5,
                      ),
                    ),

                    // ۲. بوردر فعال (نارنجی)
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:  BorderSide(
                        color: AppColors.primary,
                        width: 2.0,
                      ),
                    ),

                    labelStyle: const TextStyle(
                      color:AppColors.black6,
                    ), // رنگ پیش‌فرض متن
                    filled: true,
                    fillColor: Colors.grey[50],
                  ),
                ),
                const SizedBox(height: 20),

                // دسته‌بندی‌ها
                Row(mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const Text(
                      'دسته‌بندی‌ها',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey[300]!),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        spacing: 10,
                        runSpacing: 8,
                        children: _availableCategories.map((category) {
                          final isSelected = _selectedCategories.contains(
                            category,
                          );
                          return GestureDetector(
                            onTap: () {
                              setState(() {
                                if (isSelected) {
                                  _selectedCategories.remove(category);
                                } else {
                                  _selectedCategories.add(category);
                                }
                              });
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? AppColors.tertiary
                                    : Colors.grey[100],
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: isSelected
                                      ? AppColors.primary
                                      : Colors.grey[300]!,
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    category,
                                    style: TextStyle(
                                      color: isSelected
                                          ? AppColors.primary
                                          :AppColors.black5  ,
                                      fontWeight: isSelected
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                    ),
                                  ),
                                  if (isSelected)
                                    Icon(
                                      Icons.close,
                                      size: 16,
                                      color: AppColors.primary,
                                    ),
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'انتخاب شده: ${_selectedCategories.join(', ')}',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 30),

              ],
            ),
          ),
        ),
      ),
    );
  }
}
