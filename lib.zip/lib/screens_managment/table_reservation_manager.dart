import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../theme/app_text_theme.dart';

enum ReservationStatus { newStatus, confirmed, rejected }


class ReservationManagementPage extends StatefulWidget {
  const ReservationManagementPage({super.key});

  @override
  State<ReservationManagementPage> createState() => _ReservationManagementPageState();
}

class _ReservationManagementPageState extends State<ReservationManagementPage> {
  // داده‌های نمونه
  List<Map<String, dynamic>> reservations = [
    {
      'id': 1,
      'name': 'علی محمدی',
      'phone': '09123456789',
      'guests': 4,
      'reservationDate': '1403/08/15',
      'reservationTime': '19:30',
      'message': 'می‌خواهیم برای شام رزرو کنیم، میز کنار پنجره می‌خواهیم.',
      'requestDate': '1403/08/10 - 10:00',
      'status': ReservationStatus.newStatus,
      'reply': '', // خالی است
    },
    {
      'id': 2,
      'name': 'سارا احمدی',
      'phone': '09351234567',
      'guests': 2,
      'reservationDate': '1403/08/12',
      'reservationTime': '12:00',
      'message': 'تولد همسرم است، لطفاً کیک آماده کنید.',
      'requestDate': '1403/08/11 - 14:20',
      'status': ReservationStatus.confirmed,
      'reply': 'تبریک می‌گویم! کیک و میز کنار پنجره رزرو شد.',
    },
    {
      'id': 3,
      'name': 'کاوه نوری',
      'phone': '09198765432',
      'guests': 6,
      'reservationDate': '1403/08/14',
      'reservationTime': '20:00',
      'message': 'برای جلسه کاری نیاز به میز بزرگ داریم.',
      'requestDate': '1403/08/12 - 09:15',
      'status': ReservationStatus.rejected,
      'reply': 'متاسفانه در آن ساعت ظرفیت نداریم.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        centerTitle: true,
        excludeHeaderSemantics: true,
        elevation: 0,
        leading:SizedBox(),
        scrolledUnderElevation: 0,
        backgroundColor: AppColors.tertiary,
        title: Text(
          'مدیریت رزروها',
          style: AppTextTheme.textTheme.bodyLarge!.copyWith(
            color: AppColors.secondary,
          ),
        ),
      ),
      body: Directionality(textDirection: TextDirection.rtl,
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: reservations.length,
          itemBuilder: (context, index) {
            final res = reservations[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(color: Colors.grey[200]!, width: 1),
              ),
              child: InkWell(
                onTap: () => _showReservationDialog(context, res),
                borderRadius: BorderRadius.circular(16),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ردیف اول: آیکون، نام، زمان و وضعیت
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CircleAvatar(
                            radius: 24,
                            backgroundColor: AppColors.tertiary.withOpacity(0.3),
                            child: Text(
                              res['name'][0],
                              style: TextStyle(
                                color: AppColors.secondary,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  res['name'],
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: AppColors.textDark,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  '📅 ${res['reservationDate']} |  ${res['reservationTime']} |  ${res['guests']} نفر',
                                  style: TextStyle(
                                    color: AppColors.textLight,
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // باکس وضعیت با عرض ثابت
                          SizedBox(
                            width: 90,
                            child: _buildStatusBadge(res['status']),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildStatusBadge(ReservationStatus status) {
    String label;
    Color bgColor;
    Color textColor;
    IconData icon;

    switch (status) {
      case ReservationStatus.newStatus:
        label = 'جدید';
        bgColor = AppColors.primary.withOpacity(0.15);
        textColor = AppColors.primary;
        icon = Icons.notifications_active;
        break;
      case ReservationStatus.confirmed:
        label = 'تایید شده';
        bgColor = AppColors.tertiary.withOpacity(0.3);
        textColor = AppColors.secondary;
        icon = Icons.check_circle;
        break;
      case ReservationStatus.rejected:
        label = 'رد شده';
        bgColor = AppColors.secondary.withOpacity(0.15);
        textColor = AppColors.secondary;
        icon = Icons.cancel;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: textColor.withOpacity(0.3), width: 1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 14, color: textColor),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: textColor,
              fontWeight: FontWeight.bold,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  void _showReservationDialog(BuildContext context, Map<String, dynamic> res) {
    ReservationStatus currentStatus = res['status'];
    final TextEditingController replyController = TextEditingController(text: res['reply'] ?? '');

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          return Directionality(textDirection: TextDirection.rtl,
            child: Dialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
              elevation: 0,
              backgroundColor: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // هدر دیالوگ
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'جزئیات رزرو',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: AppColors.textDark,
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close, color: AppColors.textLight),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // اطلاعات کاربر
                      _buildInfoCard('اطلاعات کاربر', [
                        _buildInfoRow('نام', res['name'], Icons.person),
                        _buildInfoRow('شماره تماس', res['phone'], Icons.phone),
                        _buildInfoRow('تعداد نفرات', '${res['guests']} نفر', Icons.group),
                      ]),

                      const SizedBox(height: 16),

                      // اطلاعات رزرو
                      _buildInfoCard('زمان رزرو', [
                        _buildInfoRow('تاریخ', res['reservationDate'], Icons.calendar_today),
                        _buildInfoRow('ساعت', res['reservationTime'], Icons.access_time),
                        _buildInfoRow('زمان درخواست', res['requestDate'], Icons.access_time_filled),
                      ]),

                      const SizedBox(height: 16),

                      // متن درخواست کاربر
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppColors.tertiary.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.tertiary.withOpacity(0.5)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'متن درخواست:',
                              style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.secondary),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              res['message'],
                              style: const TextStyle(fontSize: 14, color: AppColors.textDark),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // نمایش وضعیت پاسخ (در دیالوگ)
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.grey[300]!),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'وضعیت پاسخ:',
                              style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.textDark),
                            ),
                            const SizedBox(height: 8),
                            if (res['reply'] != null && res['reply'].isNotEmpty)
                              Text(
                                res['reply'],
                                style: const TextStyle(fontSize: 14, color: AppColors.textDark),
                              )
                            else
                              Text(
                                'پاسخی ارسال نشده',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey[500],
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // تغییر وضعیت
                      const Text(
                        'تغییر وضعیت:',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      const SizedBox(height: 12),
                      // جایگزین ChoiceChip با FilterChip
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: ReservationStatus.values.map((status) {
                          return FilterChip(
                            label: Text(_getStatusLabel(status)),
                            selected: currentStatus == status,
                            selectedColor: AppColors.primary.withOpacity(0.2),
                            checkmarkColor: AppColors.primary,
                            labelStyle: TextStyle(
                              color: currentStatus == status ? AppColors.primary : AppColors.textDark,
                              fontWeight: FontWeight.bold,
                            ),
                            onSelected: (selected) {
                              if (selected) {
                                setDialogState(() {
                                  currentStatus = status;
                                });
                              }
                            },
                          );
                        }).toList(),
                      ),


                      const SizedBox(height: 24),

                      // پاسخ (ویرایش)
                      const Text(
                        'پاسخ شما:',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: replyController,
                        maxLines: 4,
                        decoration: InputDecoration(
                          hintText: 'متن پاسخ را بنویسید...',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide(color: Colors.grey[300]!),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide(color: Colors.grey[300]!),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide:  BorderSide(color: AppColors.primary, width: 2),
                          ),
                          filled: true,
                          fillColor: Colors.grey[50],
                          contentPadding: const EdgeInsets.all(16),
                        ),
                      ),

                      const SizedBox(height: 24),

                      // دکمه‌ها
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => Navigator.pop(context),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                side: BorderSide(color: Colors.grey[400]!),
                              ),
                              child: const Text('انصراف'),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  res['status'] = currentStatus;
                                  res['reply'] = replyController.text;
                                });
                                Navigator.pop(context);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: const Text('تغییرات با موفقیت ذخیره شد'),
                                    backgroundColor: AppColors.primary,
                                    behavior: SnackBarBehavior.floating,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primary,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                elevation: 0,
                              ),
                              child: const Text('ذخیره و پاسخ'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildInfoCard(String title, List<Widget> children) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[200]!),
        boxShadow: [
          BoxShadow(color: Colors.grey.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 2)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.secondary, fontSize: 14),
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 16, color: AppColors.primary),
          const SizedBox(width: 8),
          Text(
            '$label: ',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppColors.textDark),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 13, color: AppColors.textLight),
            ),
          ),
        ],
      ),
    );
  }

  String _getStatusLabel(ReservationStatus status) {
    switch (status) {
      case ReservationStatus.newStatus:
        return 'جدید';
      case ReservationStatus.confirmed:
        return 'تایید شده';
      case ReservationStatus.rejected:
        return 'رد شده';
    }
  }
}
