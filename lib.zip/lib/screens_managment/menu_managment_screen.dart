import 'package:coffechi2/theme/app_colors.dart';
import 'package:flutter/material.dart';

import '../theme/app_text_theme.dart';

class MenuManagmentScreen extends StatefulWidget {
  const MenuManagmentScreen({super.key});

  @override
  State<MenuManagmentScreen> createState() => _MenuManagmentScreenState();
}

class _MenuManagmentScreenState extends State<MenuManagmentScreen> {
  // داده‌های نمونه
  List<MenuCategory> categories = [
    MenuCategory(
      id: '1',
      name: 'نوشیدنی‌ها',
      items: [
        MenuItem(id: '101', name: 'قهوه اسپرسو', price: 45000, description: 'تک شات'),
        MenuItem(id: '102', name: 'چای سیاه', price: 20000, description: 'با لیمو'),
      ],
    ),
    MenuCategory(
      id: '2',
      name: 'غذاهای اصلی',
      items: [
        MenuItem(id: '201', name: 'پلو با مرغ', price: 120000, description: 'با سبزیجات'),
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text(
          'مدیریت منو',
          style: AppTextTheme.textTheme.bodyLarge!.copyWith(
            color: AppColors.secondary,
          ),
        ),
        centerTitle: true,
        backgroundColor: AppColors.tertiary,
        elevation: 0,
      ),


      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          return Directionality(
            textDirection: TextDirection.rtl,
            child: Card(
              margin: EdgeInsets.all(8),
              child: ExpansionTile(
               title: Text(category.name, style: TextStyle(fontWeight: FontWeight.bold)),
                trailing: IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: () => _editCategory(category),
                ),
            
                children: [
                  // لیست آیتم‌های این دسته
                  ...category.items.map((item) => ListTile(
                    // حذف بخش leading
                    title: Text(item.name),
                    subtitle: Text(item.description ?? 'بدون توضیحات'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star, color: Colors.amber, size: 16),
                        Text('4.5'),
                        SizedBox(width: 8),
                        Text('\$${item.price}', style: TextStyle(fontWeight: FontWeight.bold)),
                        SizedBox(width: 8),
                        IconButton(icon: Icon(Icons.delete, color: Colors.red), onPressed: () => _deleteItem(category, item)),
                      ],
                    ),
                    onTap: () => _editItem(item),
                  )).toList(),

                  // دکمه افزودن آیتم به این دسته
                  ListTile(
                    leading: Icon(Icons.add_circle_outline),
                    title: Text('افزودن آیتم جدید'),
                    onTap: () => _addItemToCategory(category),
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addNewCategory(),
        child: Icon(Icons.add,color: AppColors.secondary,),backgroundColor: AppColors.tertiary,
      ),
    );
  }
  // 1. افزودن دسته جدید
  void _addNewCategory() {
    final TextEditingController nameController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('افزودن دسته جدید'),
          content: TextField(
            controller: nameController,
            decoration: const InputDecoration(labelText: 'نام دسته'),
            autofocus: true,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('لغو'),
            ),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.isNotEmpty) {
                  setState(() {
                    categories.add(MenuCategory(
                      id: DateTime.now().millisecondsSinceEpoch.toString(),
                      name: nameController.text,
                      items: [],
                    ));
                  });
                  Navigator.pop(ctx);
                }
              },
              child: const Text('افزودن'),
            ),
          ],
        ),
      ),
    );
  }

  // 2. ویرایش دسته
  void _editCategory(MenuCategory cat) {
    final TextEditingController nameController = TextEditingController(text: cat.name);

    showDialog(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('ویرایش دسته'),
          content: TextField(
            controller: nameController,
            decoration: const InputDecoration(labelText: 'نام دسته'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('لغو'),
            ),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.isNotEmpty) {
                  setState(() {
                    cat.name = nameController.text;
                  });
                  Navigator.pop(ctx);
                }
              },
              child: const Text('ذخیره'),
            ),
          ],
        ),
      ),
    );
  }

  // 3. حذف آیتم
  void _deleteItem(MenuCategory cat, MenuItem item) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تایید حذف'),
        content: Text('آیا از حذف "${item.name}" مطمئن هستید؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('لغو'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                cat.items.remove(item);
              });
              Navigator.pop(ctx);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
  }

  // 4. افزودن آیتم به دسته
  void _addItemToCategory(MenuCategory cat) {
    final TextEditingController nameController = TextEditingController();
    final TextEditingController priceController = TextEditingController();
    final TextEditingController descController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('افزودن آیتم جدید'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'نام آیتم'),
                ),
                TextField(
                  controller: priceController,
                  decoration: const InputDecoration(labelText: 'قیمت'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: descController,
                  decoration: const InputDecoration(labelText: 'توضیحات'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('لغو'),
            ),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.isNotEmpty && priceController.text.isNotEmpty) {
                  final price = double.tryParse(priceController.text) ?? 0.0;
                  setState(() {
                    cat.items.add(MenuItem(
                      id: DateTime.now().millisecondsSinceEpoch.toString(),
                      name: nameController.text,
                      price: price,
                      description: descController.text.isEmpty ? null : descController.text,
                    ));
                  });
                  Navigator.pop(ctx);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('لطفا نام و قیمت را وارد کنید')),
                  );
                }
              },
              child: const Text('افزودن'),
            ),
          ],
        ),
      ),
    );
  }

  // 5. ویرایش آیتم
  void _editItem(MenuItem item) {
    final TextEditingController nameController = TextEditingController(text: item.name);
    final TextEditingController priceController = TextEditingController(text: item.price.toString());
    final TextEditingController descController = TextEditingController(text: item.description ?? '');

    showDialog(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('ویرایش آیتم'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'نام آیتم'),
                ),
                TextField(
                  controller: priceController,
                  decoration: const InputDecoration(labelText: 'قیمت'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: descController,
                  decoration: const InputDecoration(labelText: 'توضیحات'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('لغو'),
            ),
            ElevatedButton(
              onPressed: () {
                final price = double.tryParse(priceController.text) ?? item.price;
                setState(() {
                  item.name = nameController.text;
                  item.price = price;
                  item.description = descController.text.isEmpty ? null : descController.text;
                });
                Navigator.pop(ctx);
              },
              child: const Text('ذخیره'),
            ),
          ],
        ),
      ),
    );
  }

}
class MenuItem {
  final String id;
  late final String name;
  late final double price;
  late final String? description;
  final List<String> reviews; // یا یک مدل جداگانه برای نظرات
  final bool isActive;

  MenuItem({
    required this.id,
    required this.name,
    required this.price,
    this.description,
    this.reviews = const [],
    this.isActive = true,
  });
}

class MenuCategory {
  final String id;
  late final String name;
  final List<MenuItem> items;

  MenuCategory({
    required this.id,
    required this.name,
    this.items = const [],
  });
}
