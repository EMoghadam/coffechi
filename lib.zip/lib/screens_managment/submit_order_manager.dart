import 'package:coffechi2/theme/app_colors.dart';
import 'package:flutter/material.dart';

import '../theme/app_text_theme.dart';

class OrderManagementPage extends StatefulWidget {
  const OrderManagementPage({super.key});

  @override
  State<OrderManagementPage> createState() => _OrderManagementPageState();
}

class _OrderManagementPageState extends State<OrderManagementPage> {
  int _selectedCategoryIndex = 0;
  List<Map<String, dynamic>> _cartItems = [];

  // داده‌های نمونه منو
  final List<Map<String, dynamic>> _menuItems = [
    {
      'id': 1,
      'name': 'پیتزا پپرونی',
      'price': 250000,
      'category': 'غذای اصلی',
      'image': 'assets/images/restaurant_1.jpg',
    },
    {
      'id': 2,
      'name': 'پاستا آلفردو',
      'price': 180000,
      'category': 'غذای اصلی',
      'image': 'assets/images/restaurant_2.jpg',
    },
    {
      'id': 3,
      'name': 'سالاد سزار',
      'price': 120000,
      'category': 'پیش‌غذا',
      'image': 'assets/images/restaurant_3.jpg',
    },
    {
      'id': 4,
      'name': 'چیزburger',
      'price': 210000,
      'category': 'غذای اصلی',
      'image': 'assets/images/restaurant_4.jpg',
    },
    {
      'id': 5,
      'name': 'نوشابه کوکا',
      'price': 35000,
      'category': 'نوشیدنی',
      'image': 'assets/images/restaurant_5.jpg',
    },
    {
      'id': 6,
      'name': 'آب پرتقال',
      'price': 45000,
      'category': 'نوشیدنی',
      'image': 'assets/images/restaurant_1.jpg',
    },
    {
      'id': 7,
      'name': 'کیک شکلاتی',
      'price': 90000,
      'category': 'دسر',
      'image': 'assets/images/restaurant_2.jpg',
    },
    {
      'id': 8,
      'name': 'قهوه اسپرسو',
      'price': 60000,
      'category': 'نوشیدنی',
      'image': 'assets/images/restaurant_3.jpg',
    },
  ];

  final List<String> _categories = [
    'همه',
    'غذای اصلی',
    'پیش‌غذا',
    'نوشیدنی',
    'دسر',
  ];

  void _addToCart(Map<String, dynamic> item) {
    setState(() {
      final existingItem = _cartItems.firstWhere(
            (element) => element['id'] == item['id'],
        orElse: () => {
          'id': item['id'],
          'name': item['name'],
          'price': item['price'],
          'quantity': 0,
          'image': item['image'],
        },
      );

      if (existingItem['quantity'] > 0) {
        existingItem['quantity']++;
      } else {
        _cartItems.add({
          'id': item['id'],
          'name': item['name'],
          'price': item['price'],
          'quantity': 1,
          'image': item['image'],
        });
      }
    });
  }

  void _updateQuantity(int index, int change) {
    setState(() {
      _cartItems[index]['quantity'] += change;
      if (_cartItems[index]['quantity'] <= 0) {
        _cartItems.removeAt(index);
      }
    });
  }

  double get _subtotal => _cartItems.fold(
    0,
        (sum, item) => sum + (item['price'] * item['quantity']),
  );

  double get _tax => _subtotal * 0.09; // 9% مالیات
  double get _total => _subtotal + _tax;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        centerTitle: true,
        excludeHeaderSemantics: true,
        elevation: 0,
        leading:SizedBox(),
        scrolledUnderElevation: 0,
        backgroundColor: AppColors.tertiary,
        actions: [
          IconButton(
            icon: const Icon(Icons.receipt_long,color:  AppColors.secondary,),
            onPressed: () => _showReceiptDialog(),
          ),
        ],
        title: Text(
          'ثبت سفارش جدید',
          style: AppTextTheme.textTheme.bodyLarge!.copyWith(
            color: AppColors.secondary,
          ),
        ),
      ),

      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Row(
          children: [
            // بخش منو (سمت راست)
            Expanded(
              flex: 2,
              child: Column(
                children: [
                  // دسته‌بندی‌ها
                  SizedBox(
                    height: 50,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      itemCount: _categories.length,
                      itemBuilder: (context, index) {
                        final isSelected = _selectedCategoryIndex == index;
                        return Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 5,
                            vertical: 5,
                          ),
                          child: GestureDetector(
                            onTap: () =>
                                setState(() => _selectedCategoryIndex = index),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 15,
                                vertical: 8,
                              ),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? AppColors.primary
                                    : Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: isSelected
                                    ? null
                                    : [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.1),
                                    blurRadius: 4,
                                  ),
                                ],
                              ),
                              child: Text(
                                _categories[index],
                                style: TextStyle(color: isSelected
                                    ? Colors.white
                                    : Colors.black87,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  // لیست آیتم‌ها
                  Expanded(
                    child: GridView.builder(
                      padding: const EdgeInsets.all(10),
                      gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 0.75,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                      ),
                      itemCount: _menuItems.length,
                      itemBuilder: (context, index) {
                        final item = _menuItems[index];
                        // فیلتر کردن بر اساس دسته‌بندی انتخاب شده
                        if (_selectedCategoryIndex == 0 ||
                            item['category'] ==
                                _categories[_selectedCategoryIndex]) {
                          return _buildMenuItem(item);
                        }
                        return const SizedBox.shrink();
                      },
                    ),
                  ),
                  SizedBox(height: 60,)
                ],
              ),
            ),
            // خط جداکننده (فقط در دسکتاپ/تبلت)
            if (MediaQuery.of(context).size.width > 600)
              Container(width: 1, color: Colors.grey[300]),
            // بخش سبد خرید (سمت چپ)
            if (MediaQuery.of(context).size.width > 600)
              Expanded(flex: 1, child: _buildCartSection()),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItem(Map<String, dynamic> item) {
    return GestureDetector(
      onTap: () => _addToCart(item),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(15),
                ),
                child: Image.asset(
                  item['image'],
                  fit: BoxFit.cover,
                  width: double.infinity,
                  errorBuilder: (c, o, s) => Container(
                    color: Colors.grey[200],
                    child: const Icon(Icons.restaurant_menu),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item['name'],
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${item['price'].toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')} تومان',
                        style:  TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                      Icon(
                        Icons.add_circle,
                        color: AppColors.primary,
                        size: 20,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCartSection() {
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'سبد خرید',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                TextButton(
                  onPressed: () => setState(() => _cartItems.clear()),
                  child: const Text(
                    'پاک کردن',
                    style: TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _cartItems.isEmpty
                ? const Center(
              child: Text(
                'سبد خرید خالی است',
                style: TextStyle(color: Colors.grey),
              ),
            )
                : ListView.builder(
              itemCount: _cartItems.length,
              itemBuilder: (context, index) {
                final item = _cartItems[index];
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  leading: CircleAvatar(
                    radius: 20,
                    backgroundImage: NetworkImage(item['image']),
                  ),
                  title: Text(
                    item['name'],
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                  subtitle: Text(
                    '${item['price'].toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')} تومان',
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(
                          Icons.remove_circle_outline,
                          color: Colors.red,
                        ),
                        onPressed: () => _updateQuantity(index, -1),
                      ),
                      Text(
                        '${item['quantity']}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.add_circle_outline,
                          color: Colors.green,
                        ),
                        onPressed: () => _updateQuantity(index, 1),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          // بخش جمع کل
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, -5),
                ),
              ],
            ),
            child: Column(
              children: [
                _buildSummaryRow('جمع جز', _subtotal),
                _buildSummaryRow('مالیات (۹٪)', _tax),
                const Divider(height: 20),
                _buildSummaryRow('مبلغ قابل پرداخت', _total, isTotal: true),
                const SizedBox(height: 15),
                ElevatedButton(
                  onPressed: () => _showReceiptDialog(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    minimumSize: const Size(double.infinity, 50),
                  ),
                  child: const Text(
                    'ثبت نهایی سفارش',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String label, double amount, {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: isTotal ? 18 : 14,
            fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
            color: isTotal ? Colors.black87 : Colors.grey,
          ),
        ),
        Text(
          '${amount.toStringAsFixed(0).replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},')} تومان',
          style: TextStyle(
            fontSize: isTotal ? 18 : 14,
            fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
            color: isTotal ? AppColors.primary : Colors.black87,
          ),
        ),
      ],
    );
  }

  void _showReceiptDialog() {
    showDialog(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('رسید سفارش'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Divider(),
                ..._cartItems.map(
                      (item) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('${item['quantity']}x ${item['name']}'),
                        Text(
                          '${(item['price'] * item['quantity']).toStringAsFixed(0)}',
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(),
                _buildSummaryRow('جمع جز', _subtotal),
                _buildSummaryRow('مالیات', _tax),
                _buildSummaryRow('مبلغ کل', _total, isTotal: true),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('بستن'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                setState(() => _cartItems.clear());
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('سفارش با موفقیت ثبت شد!')),
                );
              },
              child: const Text('ثبت سفارش'),
            ),
          ],
        ),
      ),
    );
  }
}
