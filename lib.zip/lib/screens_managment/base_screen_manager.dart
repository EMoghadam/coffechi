import 'package:coffechi2/screens_managment/profile_screen_manager.dart';
import 'package:coffechi2/screens_managment/submit_order_manager.dart';
import 'package:coffechi2/screens_managment/table_reservation_manager.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../theme/app_colors.dart';

class BaseScreenManager extends StatefulWidget {
  const BaseScreenManager({super.key});

  @override
  State<BaseScreenManager> createState() => _BaseScreenManagerState();
}

class _BaseScreenManagerState extends State<BaseScreenManager> {
  int selectedBottomNavigationIndex = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.black9,
      extendBody: true, // برای اینکه Body زیر Bottom Bar بره و گردی مشخص بشه
      body: IndexedStack(
        index: selectedBottomNavigationIndex,
        children: getScreens(),
      ),
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.primary,
            boxShadow: [
              BoxShadow(
                color: AppColors.white.withOpacity(0.8),
                blurRadius: 1,
                offset: Offset(0, -1),
              ),
            ],
          ),
          child: BottomNavigationBar(
            backgroundColor: AppColors.tertiary,
            elevation: 0,
            currentIndex: selectedBottomNavigationIndex,
            onTap: (int index) {
              setState(() {
                selectedBottomNavigationIndex = index;
              });
            },
            type: BottomNavigationBarType.fixed,
            selectedItemColor: AppColors.secondary,
            unselectedItemColor: AppColors.black5,
            selectedLabelStyle: Theme.of(context).textTheme.bodyLarge,
            unselectedLabelStyle: Theme.of(context).textTheme.bodySmall,
            items: [
              BottomNavigationBarItem(
                icon: Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: Icon(FontAwesomeIcons.userLarge, size: 22),
                ),
                activeIcon: Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: Icon(FontAwesomeIcons.userLarge, size: 22),
                ),
                label: 'پروفایل',
              ),
              BottomNavigationBarItem(
                icon: Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: Icon(FontAwesomeIcons.basketShopping, size: 22),
                ),
                activeIcon: Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: Icon(FontAwesomeIcons.basketShopping, size: 22),
                ),
                label: 'ثبت سفارش',
              ),
              BottomNavigationBarItem(
                icon: Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: Icon(FontAwesomeIcons.add, size: 22),
                ),
                activeIcon: Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: Icon(FontAwesomeIcons.add, size: 22),
                ),
                label: 'رزرو نوبت',
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> getScreens() {
    return <Widget>[
      ProfileScreen(),
      OrderManagementPage(),
      ReservationManagementPage()
    ];
  }
}
