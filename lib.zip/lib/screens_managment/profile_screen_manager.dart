import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../theme/app_text_theme.dart';
import '../theme/padding.dart';
import 'comments_manager.dart';
import 'edit_profile_screen.dart';
import 'menu_managment_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {

  Future<void> myFunction() async {
    print('refreshhhhhh');
    return;
  }
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppColors.black10,
        appBar: AppBar(
          centerTitle: true,
          excludeHeaderSemantics: true,
          elevation: 0,
          leading:SizedBox(),
          scrolledUnderElevation: 0,
          backgroundColor: AppColors.tertiary,
          title: Text(
            'پروفایل مجموعه',
            style: AppTextTheme.textTheme.bodyLarge!.copyWith(
              color: AppColors.secondary,
            ),
          ),
        ),
        body: SingleChildScrollView(
            child: RefreshIndicator(
              onRefresh: () async{
                await myFunction();
              },
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    // بخش عکس پروفایل و نام
                    Center(
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 60,
                            backgroundColor: Colors.white,
                            child: CircleAvatar(
                              radius: 58,
                              backgroundImage: AssetImage(
                                'assets/images/restaurant_1.jpg',
                              ),
                            ),
                          ),

                          const SizedBox(height: 15),
                          const Text(
                            'کافه رستوران دنج',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.star, color: Colors.amber, size: 22),
                              const SizedBox(width: 5),
                              const Text(
                                '4.8',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black54,
                                ),
                              ),
                              const SizedBox(width: 5),
                              const Text(
                                '(۱۲۰ نظر)',
                                style: TextStyle(fontSize: 14, color: Colors.grey),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: getCustomOutLinBotton(
                            textName: 'مدیرت منو',
                            function: () {
                              Navigator.push(context, MaterialPageRoute(
                                  builder: (context) => MenuManagmentScreen()));
                            },
                          ),
                        ),
                        SizedBox(width: 5),
                        Expanded(
                          child: getCustomOutLinBotton(
                            textName: 'نظرات',
                            function: () {
                              Navigator.push(context, MaterialPageRoute(
                                  builder: (context) => CommentsManager()));

                            },
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 5),
                    Row(
                      children: [
                        Expanded(
                          child: getCustomBotton(
                            textName: 'ویرایش اطلاعات',
                            function: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      EditProfilePage(
                                        initialName: 'تست نام',
                                        initialAddress: 'ادرس تست',
                                        initialPhone: 'عکس تست',
                                        initialHours: 'ساعت تست',
                                        initialCategories: 'کتگوری تست',
                                        initialImageUrl: 'ادرس عکس تست',
                                      ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    // بخش اطلاعات تماس و آدرس
                    _buildInfoCard(
                      context,
                      icon: Icons.location_on,
                      title: 'آدرس',
                      subtitle: 'تهران، خیابان ولیعصر، کوچه گل‌ها، پلاک ۱۰',
                    ),
                    const SizedBox(height: 15),
                    _buildInfoCard(
                      context,
                      icon: Icons.phone,
                      title: 'تلفن',
                      subtitle: '۰۲۱-۸۸۸۸۸۸۸۸',
                    ),
                    const SizedBox(height: 15),
                    _buildInfoCard(
                      context,
                      icon: Icons.access_time,
                      title: 'ساعات کاری',
                      subtitle: 'هر روز: ۸ صبح تا ۱۱ شب',
                    ),
                    const SizedBox(height: 15),
                    _buildInfoCard(
                      context,
                      icon: Icons.category,
                      title: 'دسته‌بندی',
                      subtitle: 'کافه، رستوران، فست‌فود',
                    ),

                    const SizedBox(height: 50),
                  ],
                ),
              ),
            ),
          ),

      ),
    );
  }

  Widget getCustomBotton({required textName, required function}) {
    return ElevatedButton(
      onPressed: function,
      style: ElevatedButton.styleFrom(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16), // شعاع گردی گوشه‌ها
        ),
        backgroundColor: AppColors.primary,
        // رنگ پس‌زمینه دکمه
        foregroundColor: AppColors.black,
        // رنگ متن/آیکن دکمه
        elevation: 4,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
        textStyle: AppTextTheme.textTheme.bodyMedium,
      ),
      child: Text(textName, style: AppTextTheme.textTheme.bodyMedium),
    );
  }

  Widget getCustomOutLinBotton({required textName, required function}) {
    return SizedBox(
      child: OutlinedButton(
        onPressed: function,
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16), // شعاع گردی گوشه‌ها
          ),
          side: BorderSide(
            color: AppColors.primary, // 👈 رنگ بوردر
            width: 2, // 👈 ضخامت بوردر
          ),
          foregroundColor: AppColors.black,
          elevation: 4,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
          textStyle: AppTextTheme.textTheme.bodyMedium,
        ),
        child: Text(
          textName,
          style: AppTextTheme.textTheme.bodyMedium!.copyWith(
            color: AppColors.primary,
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard(BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.tertiary,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: AppColors.primary),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
