import 'package:dio/dio.dart';

import '../core/network/api_error_handler.dart';
import '../dio_client.dart';
import '../models/auth_response.dart';
import '../models/cafe_type.dart';

class ApiService {
  final Dio _dio = DioClient().dio;

  Future<AuthResponse> login(
      String username,
      String password,
      bool isCustomer,
      ) async {
    try {
      final response = await _dio.post(
        '/auth/login',
        data: {
          'username': username,
          'password': password,
          'isCustomer': isCustomer,
        },
      );

      return AuthResponse.fromJson(response.data);
    } on DioException catch (e) {
      throw Exception(ApiErrorHandler.handle(e));
    }
  }

  Future<AuthResponse> register({
    required String username,
    required String password,
    required bool isCustomer,
    String? firstName,
    String? lastName,
    String? cafeName,
  }) async {
    final Map<String, dynamic> requestData = {
      'username': username,
      'password': password,
      'isCustomer': isCustomer,
      'name': isCustomer
          ? '${firstName ?? ''} ${lastName ?? ''}'.trim()
          : (cafeName ?? ''),
    };

    try {
      final response = await _dio.post(
        '/auth/register',
        data: requestData,
      );

      return AuthResponse.fromJson(response.data);
    } on DioException catch (e) {
      throw Exception(ApiErrorHandler.handle(e));
    }
  }

  Future<List<CafeType>> getCafeTypes() async {
    try {
      final response = await _dio.get(
        '/auth/crtypelist',
      );

      final List<dynamic> data = response.data;

      return data
          .map((json) => CafeType.fromJson(json))
          .toList();
    } on DioException catch (e) {
      throw Exception(ApiErrorHandler.handle(e));
    }
  }
}