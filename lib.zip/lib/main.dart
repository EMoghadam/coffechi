import 'package:coffechi2/screens_coustomer/base_screen_coustomer.dart';
import 'package:coffechi2/screens_managment/base_screen_manager.dart';
import 'package:coffechi2/sign_up_screen.dart';
import 'package:coffechi2/splash_screen.dart';
import 'package:coffechi2/theme/app_colors.dart';
import 'package:coffechi2/theme/app_text_theme.dart';
import 'package:flutter/material.dart';
import 'Login_Screen.dart';
import 'dio_client.dart';

void main() {
  print('🚀 [APP] شروع برنامه');
  print('🚀 [APP] مقداردهی DioClient...');

  final dioClient = DioClient();
  dioClient.init();

  print('🚀 [APP] اجرای runApp');
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    print('🎨 [APP] ساختن ویجت MyApp');

    return MaterialApp(
      routes: {
        '/': (context) {
          print('📍 [ROUTE] رفتن به SplashScreen');
          return const SplashScreen();
        },
        '/BaseScreenCoustomer': (context) {
          print('📍 [ROUTE] رفتن به BaseScreenCustomer');
          return const BaseScreenCostomer();
        },
        '/BaseScreenManager': (context) {
          print('📍 [ROUTE] رفتن به BaseScreenManager');
          return const BaseScreenManager();
        },
        '/LoginScreen': (context) {
          print('📍 [ROUTE] رفتن به LoginScreen');
          return const LoginScreen();
        },
        '/SignupScreen': (context) {
          print('📍 [ROUTE] رفتن به SignupScreen');
          return const SignupScreen();
        },
      },
      theme: ThemeData(
        fontFamily: AppTextTheme.fontFamily,
        primaryColor: AppColors.primary,
        colorScheme: ColorScheme.light(
          primary: AppColors.primary,
          secondary: AppColors.secondary,
        ),
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}