import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

class CafeListPage extends StatefulWidget {
  const CafeListPage({super.key});

  @override
  State<CafeListPage> createState() => _CafeListPageState();
}

class _CafeListPageState extends State<CafeListPage> {
  final List<Map<String, String>> cafes = [
    {
      "name": "کافه موکا",
      "image": "assets/images/coffee_1.jpg",
      "rating": "4.6",
      "distance": "1.2 km",
      "time": "25 min",
    },
    {
      "name": "رستوران ایتالیایی رومانو",
      "image": "assets/images/coffee_2.jpg",
      "rating": "4.8",
      "distance": "2 km",
      "time": "30 min",
    },
    {
      "name": "کافه استاربین",
      "image": "assets/images/coffee_3.jpg",
      "rating": "4.5",
      "distance": "900 m",
      "time": "20 min",
    },
    {
      "name": "کافه موکا",
      "image": "assets/images/coffee_1.jpg",
      "rating": "4.6",
      "distance": "1.2 km",
      "time": "25 min",
    },
    {
      "name": "رستوران ایتالیایی رومانو",
      "image": "assets/images/coffee_2.jpg",
      "rating": "4.8",
      "distance": "2 km",
      "time": "30 min",
    },
    {
      "name": "کافه استاربین",
      "image": "assets/images/coffee_3.jpg",
      "rating": "4.5",
      "distance": "900 m",
      "time": "20 min",
    },
  ];

  String searchText = "";

  @override
  Widget build(BuildContext context) {
    final filtered = cafes.where((cafe) {
      return cafe["name"]!.toLowerCase().contains(searchText.toLowerCase());
    }).toList();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: const Text("کافه و رستوران‌ها"),
          backgroundColor: AppColors.primary,
        ),
        body: Column(
          children: [
            /// SEARCH
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                onChanged: (value) {
                  setState(() {
                    searchText = value;
                  });
                },
                decoration: InputDecoration(
                  hintText: "جستجوی کافه یا رستوران...",
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),

            /// GRID LIST
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                    childAspectRatio: 1.11

                ),
                itemCount: filtered.length,
                itemBuilder: (context, index) {
                  final cafe = filtered[index];

                  return CafeCard(
                    name: cafe["name"]!,
                    image: cafe["image"]!,
                    rating: cafe["rating"]!,
                    distance: cafe["distance"]!,
                    time: cafe["time"]!,
                  );
                },
              ),
            ),
            SizedBox(height: 70,)
          ],
        ),
      ),
    );
  }
}

class CafeCard extends StatelessWidget {
  final String name;
  final String image;
  final String rating;
  final String distance;
  final String time;

  const CafeCard({
    super.key,
    required this.name,
    required this.image,
    required this.rating,
    required this.distance,
    required this.time,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {},
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            /// IMAGE
            ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(16),
              ),
              child: Image.asset(
                image,
                height: 110,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),

            /// INFO
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  Text(
                    name,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      color: AppColors.textDark,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),

                  const SizedBox(height: 6),

                  Row(
                    children: [
                      const Icon(Icons.star,
                          size: 16, color: Colors.amber),
                      const SizedBox(width: 3),
                      Text(rating),

                      const SizedBox(width: 8),

                      const Icon(Icons.location_on,
                          size: 16, color: Colors.grey),
                      const SizedBox(width: 3),
                      Text(distance),
                    ],
                  ),

                  const SizedBox(height: 4),

                  Row(
                    children: [
                      const Icon(Icons.access_time,
                          size: 16, color: Colors.grey),
                      const SizedBox(width: 3),
                      Text(time),
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}


