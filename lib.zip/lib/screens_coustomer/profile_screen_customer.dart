import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

class CustomerProfilePage extends StatelessWidget {
  const CustomerProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: ListView(
        children: [

          /// HEADER
          Container(
            padding: const EdgeInsets.only(top: 55, left: 20, right: 20, bottom: 25),
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(35),
                bottomRight: Radius.circular(35),
              ),
            ),
            child: Row(
              children: const [
                CircleAvatar(
                  radius: 36,
                  backgroundImage: NetworkImage("https://i.pravatar.cc/150"),
                ),
                SizedBox(width: 15),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("علی رضایی",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold)),
                    SizedBox(height: 4),
                    Text("09123456789",
                        style: TextStyle(color: Colors.white70))
                  ],
                )
              ],
            ),
          ),

          const SizedBox(height: 20),

          /// QUICK STATS
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 18),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: const [
                    ProfileStat("24", "سفارش"),
                    ProfileStat("120", "امتیاز"),
                    ProfileStat("450k", "کیف پول"),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          /// ACCOUNT
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Column(
                children: [
                  ProfileItem(
                    icon: Icons.receipt_long,
                    title: "سفارش‌های من",
                    page: const OrdersPage(),
                  ),
                  const Divider(height: 1),
                  ProfileItem(
                    icon: Icons.location_on_outlined,
                    title: "آدرس‌های من",
                    page: const AddressesPage(),
                  ),
                  const Divider(height: 1),
                  ProfileItem(
                    icon: Icons.account_balance_wallet_outlined,
                    title: "کیف پول",
                    page: const WalletPage(),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 15),

          /// OTHER
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              child: Column(
                children: [
                  ProfileItem(
                    icon: Icons.star_border,
                    title: "باشگاه مشتریان",
                    page: const LoyaltyPage(),
                  ),
                  const Divider(height: 1),
                  ProfileItem(
                    icon: Icons.rate_review_outlined,
                    title: "نظرات من",
                    page: const ReviewsPage(),
                  ),
                  const Divider(height: 1),
                  ProfileItem(
                    icon: Icons.settings,
                    title: "تنظیمات",
                    page: const SettingsPage(),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 30),
        ],
      ),
    );
  }
}

class ProfileItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final Widget page;

  const ProfileItem(
      {super.key, required this.icon, required this.title, required this.page});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary),
      title: Text(title,
          style: const TextStyle(
              color: AppColors.textDark, fontWeight: FontWeight.w500)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => page),
        );
      },
    );
  }
}

class ProfileStat extends StatelessWidget {
  final String value;
  final String title;

  const ProfileStat(this.value, this.title, {super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value,
            style: TextStyle(
                color: AppColors.primary,
                fontWeight: FontWeight.bold,
                fontSize: 18)),
        const SizedBox(height: 4),
        Text(title,
            style: const TextStyle(color: AppColors.textLight, fontSize: 12))
      ],
    );
  }
}

class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});

  final orders = const [
    {"title": "پیتزا مخصوص", "price": "280,000", "date": "1405/02/20"},
    {"title": "برگر کلاسیک", "price": "190,000", "date": "1405/02/15"},
    {"title": "لاته", "price": "90,000", "date": "1405/02/10"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("سفارش‌های من"),
        backgroundColor: AppColors.primary,
      ),
      body: ListView.builder(
        itemCount: orders.length,
        itemBuilder: (context, i) {
          final order = orders[i];
          return Card(
            margin: const EdgeInsets.all(10),
            child: ListTile(
              leading: const Icon(Icons.restaurant),
              title: Text(order["title"]!),
              subtitle: Text(order["date"]!),
              trailing: Text("${order["price"]} تومان"),
            ),
          );
        },
      ),
    );
  }
}

class AddressesPage extends StatelessWidget {
  const AddressesPage({super.key});

  final addresses = const [
    "تهران - خیابان ولیعصر - پلاک 120",
    "تهران - سعادت آباد - میدان کاج",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("آدرس‌های من"),
        backgroundColor: AppColors.primary,
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primary,
        onPressed: () {},
        child: const Icon(Icons.add),
      ),
      body: ListView.builder(
        itemCount: addresses.length,
        itemBuilder: (context, i) {
          return Card(
            margin: const EdgeInsets.all(10),
            child: ListTile(
              leading: const Icon(Icons.location_on),
              title: Text(addresses[i]),
            ),
          );
        },
      ),
    );
  }
}

class WalletPage extends StatelessWidget {
  const WalletPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("کیف پول"),
        backgroundColor: AppColors.primary,
      ),
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(20),
          child: Padding(
            padding: const EdgeInsets.all(25),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text("موجودی شما",
                    style: TextStyle(color: AppColors.textLight)),
                const SizedBox(height: 10),
                Text("450,000 تومان",
                    style: TextStyle(
                        fontSize: 26,
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class LoyaltyPage extends StatelessWidget {
  const LoyaltyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("باشگاه مشتریان"),
        backgroundColor: AppColors.primary,
      ),
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(20),
          child: Padding(
            padding: const EdgeInsets.all(25),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.star, size: 60, color: AppColors.tertiary),
                SizedBox(height: 10),
                Text("امتیاز شما: 120", style: TextStyle(fontSize: 20)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ReviewsPage extends StatelessWidget {
  const ReviewsPage({super.key});

  final reviews = const [
    {"food": "پیتزا", "comment": "خیلی خوشمزه بود"},
    {"food": "لاته", "comment": "عالی بود"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("نظرات من"),
        backgroundColor: AppColors.primary,
      ),
      body: ListView.builder(
        itemCount: reviews.length,
        itemBuilder: (context, i) {
          final r = reviews[i];
          return Card(
            margin: const EdgeInsets.all(10),
            child: ListTile(
              leading: const Icon(Icons.comment),
              title: Text(r["food"]!),
              subtitle: Text(r["comment"]!),
            ),
          );
        },
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("تنظیمات"),
        backgroundColor: AppColors.primary,
      ),
      body: ListView(
        children: const [
          ListTile(
            leading: Icon(Icons.person),
            title: Text("ویرایش پروفایل"),
          ),
          ListTile(
            leading: Icon(Icons.lock),
            title: Text("تغییر رمز"),
          ),
          ListTile(
            leading: Icon(Icons.logout),
            title: Text("خروج"),
          ),
        ],
      ),
    );
  }
}
