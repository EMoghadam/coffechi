import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class OrderDetailsPage extends StatelessWidget {
  const OrderDetailsPage({super.key});

  @override
  Widget build(BuildContext context) {

    final items = [
      {"name": "پاستا آلفردو", "count": 1, "price": 180000},
      {"name": "قهوه لاته", "count": 2, "price": 70000},
      {"name": "چیزکیک", "count": 1, "price": 90000},
    ];

    int total = items.fold(
        0, (sum, item) => sum + (item["price"] as int) * (item["count"] as int));

    int delivery = 30000;
    int finalPrice = total + delivery;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: const Text("جزئیات سفارش"),
          backgroundColor: AppColors.primary,
        ),
        body: ListView(
          padding: const EdgeInsets.all(12),
          children: [

            /// RESTAURANT CARD
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              child: ListTile(
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset(
                    "assets/images/coffee_1.jpg",
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                  ),
                ),
                title: const Text(
                  "کافه موکا",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: const Text("1405/03/10 - ساعت 19:40"),
                trailing: Container(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    "تحویل شده",
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 12),

            /// ORDER ITEMS
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: items.map((item) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              item["name"].toString(),
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Text("${item["count"]} × "),
                          const SizedBox(width: 6),
                          Text("${item["price"]} تومان"),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),

            const SizedBox(height: 12),

            /// ADDRESS
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              child: const ListTile(
                leading: Icon(Icons.location_on_outlined),
                title: Text("آدرس تحویل"),
                subtitle: Text(
                    "تهران، خیابان ولیعصر، بالاتر از پارک ساعی، پلاک ۲۱"),
              ),
            ),

            const SizedBox(height: 12),

            /// PAYMENT
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    priceRow("جمع سفارش", total),
                    priceRow("هزینه ارسال", delivery),
                    const Divider(),
                    priceRow("مبلغ نهایی", finalPrice, bold: true),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            /// REORDER BUTTON
            // ElevatedButton(
            //   style: ElevatedButton.styleFrom(
            //     backgroundColor: AppColors.primary,
            //     padding: const EdgeInsets.symmetric(vertical: 14),
            //     shape: RoundedRectangleBorder(
            //       borderRadius: BorderRadius.circular(12),
            //     ),
            //   ),
            //   onPressed: () {},
            //   child: const Text(
            //     "سفارش مجدد",
            //     style: TextStyle(fontSize: 16),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }

  Widget priceRow(String title, int price, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Text(title),
          const Spacer(),
          Text(
            "$price تومان",
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
              color: bold ? AppColors.primary : Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}
