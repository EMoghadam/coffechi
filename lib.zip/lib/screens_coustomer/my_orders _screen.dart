import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import 'order_details_page.dart';

class MyOrdersPage extends StatelessWidget {
  const MyOrdersPage({super.key});

  final List<Map<String, String>> orders = const [
    {
      "restaurant": "کافه موکا",
      "image": "assets/images/coffee_1.jpg",
      "status": "تحویل شده",
      "date": "1405/03/10",
      "price": "420,000",
    },
    {
      "restaurant": "رستوران رومانو",
      "image": "assets/images/coffee_2.jpg",
      "status": "در حال آماده سازی",
      "date": "1405/03/08",
      "price": "350,000",
    },
    {
      "restaurant": "کافه استاربین",
      "image": "assets/images/coffee_3.jpg",
      "status": "لغو شده",
      "date": "1405/03/05",
      "price": "180,000",
    },
  ];

  Color statusColor(String status) {
    switch (status) {
      case "تحویل شده":
        return Colors.green;
      case "در حال آماده سازی":
        return Colors.orange;
      case "لغو شده":
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: const Text("سفارش‌های من"),
          backgroundColor: AppColors.primary,
        ),
        body: ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: orders.length,
          itemBuilder: (context, index) {
            final order = orders[index];

            return Card(
              elevation: 3,
              margin: const EdgeInsets.only(bottom: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [

                    /// IMAGE
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.asset(
                        order["image"]!,
                        width: 70,
                        height: 70,
                        fit: BoxFit.cover,
                      ),
                    ),

                    const SizedBox(width: 10),

                    /// INFO
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          Text(
                            order["restaurant"]!,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              color: AppColors.textDark,
                            ),
                          ),

                          const SizedBox(height: 6),

                          Text(
                            order["date"]!,
                            style: const TextStyle(
                              fontSize: 12,
                              color: AppColors.textLight,
                            ),
                          ),

                          const SizedBox(height: 6),

                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: statusColor(order["status"]!)
                                      .withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  order["status"]!,
                                  style: TextStyle(
                                    color: statusColor(order["status"]!),
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    /// PRICE + BUTTON
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [

                        Text(
                          "${order["price"]} تومان",
                          style:  TextStyle(
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary,
                          ),
                        ),

                        const SizedBox(height: 10),

                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const OrderDetailsPage(),
                              ),
                            );
                          },
                          child: const Text("جزئیات"),
                        ),

                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
